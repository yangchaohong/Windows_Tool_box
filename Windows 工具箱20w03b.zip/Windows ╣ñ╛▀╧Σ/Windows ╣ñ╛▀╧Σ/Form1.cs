﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;

namespace Windows_工具箱
{
    public partial class Form1 : Form
    {
        public void Run(string  path,string name)
        {
            string Path = string.Format(@path);
            Process app = new Process();
            app.StartInfo.WorkingDirectory = Path;
            app.StartInfo.FileName = name;
            app.Start();
        }

        public Form1()
        {
            InitializeComponent();
        }



        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Run("application", "cpuz_x64.exe");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Run("application", "cpuz_x64.exe");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            cpuzabout cpu = new cpuzabout();
            cpu.Show();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Run("application", "国际象棋.exe");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Run("application", "国际象棋.exe");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            chessabout chess = new chessabout();
            chess.Show();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            lantern r = new lantern();
            r.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            lanternabout lan = new lanternabout();
            lan.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            lantern r = new lantern();
            r.Show();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            Run("application/Core Temp", "Core Temp.exe");
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Run("application/Core Temp", "Core Temp.exe");
        }

        private void button8_Click(object sender, EventArgs e)
        {
            ctabout ct = new ctabout();
            ct.Show();
        }
    }
}
