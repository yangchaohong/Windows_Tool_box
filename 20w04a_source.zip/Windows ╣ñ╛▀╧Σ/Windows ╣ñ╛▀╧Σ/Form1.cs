﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;

namespace Windows_工具箱
{
    public partial class Form1 : Form
    {
        public void Run(string  path,string name)
        {
            string Path = string.Format(@path);
            Process app = new Process();
            app.StartInfo.WorkingDirectory = Path;
            app.StartInfo.FileName = name;
            app.Start();
        }

        public Form1()
        {
            InitializeComponent();
        }



        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Run("application", "cpuz_x64.exe");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Run("application", "cpuz_x64.exe");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            cpuzabout cpu = new cpuzabout();
            cpu.Show();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Run("application", "国际象棋.exe");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Run("application", "国际象棋.exe");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            chessabout chess = new chessabout();
            chess.Show();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            lantern r = new lantern();
            r.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            lanternabout lan = new lanternabout();
            lan.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            lantern r = new lantern();
            r.Show();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            Run("application/Core Temp", "Core Temp.exe");
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Run("application/Core Temp", "Core Temp.exe");
        }

        private void button8_Click(object sender, EventArgs e)
        {
            ctabout ct = new ctabout();
            ct.Show();
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            Run("application/FurMark", "Furmark.exe");
        }

        private void button9_Click(object sender, EventArgs e)
        {
            Run("application/FurMark", "Furmark.exe");
        }

        private void button10_Click(object sender, EventArgs e)
        {
            furmarkabout fu = new furmarkabout();
            fu.Show();
        }

        private void 关于ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            关于 about = new 关于();
            about.Show();
        }

        private void 退出ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            Run("application", "VMware-workstation-full-15.5.1-15018445.exe");
            MessageBox.Show("激活码：CG392-4PX5J-H816Z-HYZNG-PQRG2","激活码");
        }

        private void button11_Click(object sender, EventArgs e)
        {
            Run("application", "VMware-workstation-full-15.5.1-15018445.exe");
            MessageBox.Show("激活码：CG392-4PX5J-H816Z-HYZNG-PQRG2", "激活码");
        }

        private void button12_Click(object sender, EventArgs e)
        {
            MessageBox.Show("著名的老牌虚拟机软件。", "VMware 关于");
        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {
            Run("application", "GPU-Z.2.28.0.exe");
        }

        private void button13_Click(object sender, EventArgs e)
        {
            Run("application", "GPU-Z.2.28.0.exe");
        }

        private void button14_Click(object sender, EventArgs e)
        {
            MessageBox.Show("我不知道。", "Gpu Z 关于");
        }

        private void button15_Click(object sender, EventArgs e)
        {
            Run("application", "vs_community__1551040456.1576582294.exe");
        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {
            Run("application", "vs_community__1551040456.1576582294.exe");
        }

        private void button16_Click(object sender, EventArgs e)
        {
            MessageBox.Show("看看这个软件是用什么写的就知道了。", "Visual Studio Installer 关于");
        }

        private void pictureBox9_Click(object sender, EventArgs e)
        {
            github git = new github();
            git.ShowDialog();
        }

        private void button18_Click(object sender, EventArgs e)
        {
            MessageBox.Show("我开源我快乐。", "GitHub Desktop 关于");
        }

        private void button17_Click(object sender, EventArgs e)
        {
            github git = new github();
            git.ShowDialog();
        }
    }
}
