﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Windows_工具箱
{
    public partial class lantern : Form
    {
        public void Run(string path, string name)
        {
            string Path = string.Format(@path);
            Process app = new Process();
            app.StartInfo.WorkingDirectory = Path;
            app.StartInfo.FileName = name;
            app.Start();
        }
        public lantern()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Run("application", "lantern_install.exe");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Run("application/Lantern", "lantern.exe");
        }
    }
}
